<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "e-commerce";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    
            
}?>

<!DOCTYPE html>
<html>
<head>
	<title> Buy</title>
	<link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
 <div id="body" >
 	<div id="left"></div>
 	<div id="center">
 		<div id="head"></div>
 		<div id="subhead">
<input type="text" placeholder="Search" id="search" >
			
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/home%20page/' "><i class="fa fa-home" >Home</button>
<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/contact%20us%20page/' " >Contact Us</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/sign%20up/' ">Sign Up</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/login/' " >Login</button>
 		</div>
 		<div id="mid">
 		<div id="details">
 			<button style="margin-left: 94%; border-radius: 25%" onclick="window.location.href='http://localhost:2124/website/Add%20Product/fetch.php' ">X</button>

 			<div id="img"> 
           <?php

                  $query = "Select image from addproduct where id=5";
                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1><img src ='$row[image]' width='230' height='360' /></h1>";}?> 	
 			</div>
 			<div id="text">
 				<p style="color:white;font-size:30px;font-style: italic;">

 					
                                       
                   <?php
    $query = "Select title,description from addproduct where id=5";

                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1 style='color:white;font-size:25px;font-style: italic;'>$row[title]</h1>";
                   echo "<h1 style='color:white;font-size:23.5px;font-style: italic;'>$row[description]<h1>";


               }?></p> 
 <p>
 				<button style="width: 200px;height: 40px; margin-left: 10%;border:5px solid black;font-size: 30px "onclick="window.location.href='http://localhost:2124/website/Add%20Product/cred.php' ">Add Cart</button>
 			</div>
 		</div>
 		</div>
 		<div id="footer">
 		<img src="footer.png" style="width: 1200px;height: 250px;">
 		
 		</div>
 	</div>
 	<div id="right"></div>
 </div>

</body>
</html>