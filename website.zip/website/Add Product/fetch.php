
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "e-commerce";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    
            
}
?>
<!DOCTYPE html>
<html>
<head>
	<title> Buy</title>
  
	<link rel="stylesheet" type="text/css" href="design.css">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
 <div id="body" >
 	<div id="left"></div>
 	<div id="center">
 		<div id="head"></div>
 		<div id="subhead">
<input type="text" placeholder="Search" id="search" >
			
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/home%20page/' "><i class="fa fa-home" >Home</button>
<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/contact%20us%20page/' " >Contact Us</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/sign%20up/' ">Sign Up</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/login/' " >Login</button>
 		</div>
 		<div id="mid">
 			<div id="firstrow">
 				<button id="first" onclick="window.location.href='http://localhost:2124/website/Add%20Product/prod1.php' ">
 				<?php

                  $query = "Select image from addproduct where id=1";
                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1 ><img src ='$row[image]' width='200' height='150'  /></h1>";}?>
                                       
 <p>
                   <?php
    $query = "Select title,amount from addproduct where id=1";

                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1>$row[title]</h1>";
                   echo "<p>Amount=<strong>$row[amount]</strong>/Rs</p>";


               }?></p>	
 				
        </button>
 				<button id="second" onclick="window.location.href='http://localhost:2124/website/Add%20Product/prod2.php' ">
 					
 				<?php

                  $query = "Select image from addproduct where id=2";
                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1><img src ='$row[image]' width='200' height='150'/></h1>";}?>
                                       
 <p>
                   <?php
    $query = "Select title,amount from addproduct where id=2";

                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1>$row[title]</h1>";
                   echo "<p>Amount=<strong>$row[amount]</strong>/Rs</p>";
                   


               }?></p>  	
 				</button>
 				<button id="third" onclick="window.location.href='http://localhost:2124/website/Add%20Product/prod3.php' ">
 					<?php

                  $query = "Select image from addproduct where id=3";
                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1><img src ='$row[image]' width='200' height='150'/></h1>";}?>
                                       
 <p>
                   <?php
    $query = "Select title,amount from addproduct where id=3";

                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1>$row[title]</h1>";
                   echo "<p>Amount=<strong>$row[amount]</strong>/Rs</p>";
                   


               }?></p>  
 					
 				</button>
 				<button id="forth" onclick="window.location.href='http://localhost:2124/website/Add%20Product/prod4.php' ">
 					
          <?php

                  $query = "Select image from addproduct where id=4";
                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1><img src ='$row[image]' width='200' height='150'/></h1>";}?>
                                       
 <p>
                   <?php
    $query = "Select title,amount from addproduct where id=4";

                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1>$row[title]</h1>";
                   echo "<p>Amount=<strong>$row[amount]</strong>/Rs</p>";
                   


               }?></p>  
 				</button>
 					
 			</div>
 			<div id="secondrow">
 				<button id="first" onclick="window.location.href='http://localhost:2124/website/Add%20Product/prod5.php' ">

 					<?php

                  $query = "Select image from addproduct where id=5";
                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1><img src ='$row[image]' width='200' height='150'/></h1>";}?>
                                       
 <p>
                   <?php
    $query = "Select title,amount from addproduct where id=5";

                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1>$row[title]</h1>";
                   echo "<p>Amount=<strong>$row[amount]</strong>/Rs</p>";
                   


               }?></p>  
 				</button>
 				<button id="second" onclick="window.location.href='http://localhost:2124/website/Add%20Product/prod6.php' ">
 				<?php

                  $query = "Select image from addproduct where id=6";
                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1><img src ='$row[image]' width='200' height='150'/></h1>";}?>
                                       
 <p>
                   <?php
    $query = "Select title,amount from addproduct where id=6";

                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1>$row[title]</h1>";
                   echo "<p>Amount=<strong>$row[amount]</strong>/Rs</p>";
                   


               }?></p>  
 				</button>
 				<button id="third" onclick="window.location.href='http://localhost:2124/website/Add%20Product/prod7.php' ">
 					<?php

                  $query = "Select image from addproduct where id=7";
                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1><img src ='$row[image]' width='200' height='150'/></h1>";}?>
                                       
 <p>
                   <?php
    $query = "Select title,amount from addproduct where id=7";

                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1>$row[title]</h1>";
                   echo "<p>Amount=<strong>$row[amount]</strong>/Rs</p>";
                   


               }?></p>  
 				</button>
 				<button id="forth" onclick="window.location.href='http://localhost:2124/website/Add%20Product/prod8.php' ">
 					<?php

                  $query = "Select image from addproduct where id=8";
                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1><img src ='$row[image]' width='200' height='150'/></h1>";}?>
                                       
 <p>
                   <?php
    $query = "Select title,amount from addproduct where id=8";

                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1>$row[title]</h1>";
                   echo "<p>Amount=<strong>$row[amount]</strong>/Rs</p>";
                   

               }?></p>  
 				</button>
 			</div>
 			<div id="thirdrow">
 				<button id="first" onclick="window.location.href='http://localhost:2124/website/Add%20Product/prod9.php' ">
 				
        <?php

                  $query = "Select image from addproduct where id=9";
                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1><img src ='$row[image]' width='200' height='150'/></h1>";}?>
                                       
 <p>
                   <?php
    $query = "Select title,amount from addproduct where id=9";

                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1>$row[title]</h1>";
                   echo "<p>Amount=<strong>$row[amount]</strong>/Rs</p>";
                   


               }?></p>  
 				</button>
 				<button id="second" onclick="window.location.href='http://localhost:2124/website/Add%20Product/prod10.php' ">
 					<?php

                  $query = "Select image from addproduct where id=10";
                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1><img src ='$row[image]' width='200' height='150'/></h1>";}?>
                                       
 <p>
                   <?php
    $query = "Select title,amount from addproduct where id=10";

                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1>$row[title]</h1>";
                   echo "<p>Amount=<strong>$row[amount]</strong>/Rs</p>";
                   


               }?></p>  
 				</button>
 				<button id="third" onclick="window.location.href='http://localhost:2124/website/Add%20Product/prod11.php' ">
 					
          <?php

                  $query = "Select image from addproduct where id=11";
                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1><img src ='$row[image]' width='200' height='150'/></h1>";}?>
                                       
 <p>
                   <?php
    $query = "Select title,amount from addproduct where id=11";

                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1>$row[title]</h1>";
                   echo "<p>Amount=<strong>$row[amount]</strong>/Rs</p>";
                   


               }?></p>  
 				</button>
 				<button id="forth" onclick="window.location.href='http://localhost:2124/website/Add%20Product/prod12.php' ">
 				<?php

                  $query = "Select image from addproduct where id=12";
                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1><img src ='$row[image]' width='200' height='150'/></h1>";}?>
                                       
 <p>
                   <?php
    $query = "Select title,amount from addproduct where id=12";

                   $result = mysqli_query($conn, $query);
                   while ($row = mysqli_fetch_array($result)){
                   echo "<h1>$row[title]</h1>";
                   echo "<p>Amount=<strong>$row[amount]</strong>/Rs</p>";
                   


               }?></p>  
 				</button>
 			</div>
 		</div>
 		<div id="footer">
      <button style=" margin-top: 4%;margin-left: 42.5%">
      <a href="http://localhost:2124/website/Add%20Product/fetch.php">Page 0</a>
    </button>
 			<button >
 			<a href="http://localhost:2124/website/Buy/index0.php">Page 1</a>
 		</button>
 		<button >
 			<a href="http://localhost:2124/website/Buy/index1.php">Page 2</a>
 		</button>
 		<button >
 			<a href="http://localhost:2124/website/Buy/index2.php">Page 3</a>
 		</button>
 		</div>
 	</div>
 	<div id="right"></div>
 </div>

</body>
</html>