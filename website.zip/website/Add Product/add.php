
<?php
error_reporting(0);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "e-commerce";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$ID=$_POST['txtid'];
$title=$_POST['txtname'];
$DESCRIPTION=$_POST['txtdescription'];
$amount=$_POST['txtamount'];
$filename=$_FILES["uploadfile"]["name"];
$tempname=$_FILES["uploadfile"]["tmp_name"];
$folder="img/".$filename;
move_uploaded_file($tempname, $folder);



?>


<!DOCTYPE html>
<html>
<head>
	<title> Buy</title>
	<link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
  
 <div id="body" >
 	<div id="left"></div>
 	<div id="center">
 		<div id="head"></div>
    <div id="subhead">
      
<input type="text" placeholder="Search" id="search" >
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/home%20page/' "><i class="fa fa-home" >Home</button>
<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/contact%20us%20page/' " >Contact Us</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/sign%20up/' ">Sign Up</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/login/' " >Login</button>
 		</div>
 		<div id="mid" >
      <center>
      <form method="POST" enctype="multipart/form-data" >
        <table style="border: 8px solid black;border-radius:50%;width: 30%;margin-top: 10%">
          <tr>
            <td> 
  <label style="font-size:30px;color: white " >ID</label><br>
    <input style="width: 100%;height:40px ;float: right;" type="number" name="txtid" required><br>
         
    <label style="font-size:30px;color: white ">Name</label><br>
    <input style="width: 100%;height:40px ;float: right;" type="text" name="txtname" required><br>
  
    <label style="font-size:30px;color: white">Image</label><br>
    <input style="width: 100%;height:40px ;float: right;" type="file" name="uploadfile" required><br>
  
    <label style="font-size:30px;color: white">Amount</label><br>
    <input style="width: 100%;height:40px ;float: right;" type="text" name="txtamount" required><br>

    <label style="font-size:30px;color: white">Discription</label><br>
    <input style="width: 100%;height:40px ;float: right;" type="text" name="txtdescription" required><br>
  
    <input style="width: 30%;height: 50px ;margin-top:10%" type="submit" name="Insert" value="Insert">
    <input style="width: 33%;height: 50px ;margin-top:10%" type="submit" name="Update" value="Update">
    <input style="width: 33%;height: 50px ;margin-top:10%" type="submit" name="Delete" value="Delete">
    <button style="width:100%;height: 50px ;margin-top:10% ;border: 4px solid black ;font-size: 30px" onclick="window.location.href='http://localhost:2124/website/Add%20Product/fetch.php' ">Logout</button>
   </td>
 </tr>
 <?php 
 if (isset($_POST["Insert"])) {

$sql = "INSERT INTO Addproduct 
VALUES ('$folder','$title','$ID', '$DESCRIPTION','amount')";
if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}


if (isset($_POST["Update"])) {

$sql = "UPDATE  Addproduct 
SET image='$folder',title='$title',id='$ID',description='$DESCRIPTION',amount='$amount'
WHERE id='$ID'";

if (mysqli_query($conn, $sql)) {
    echo " record updated successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);

}
}

if (isset($_POST["Delete"])) {

$sql = "DELETE FROM Addproduct 

WHERE id='$ID'";

if (mysqli_query($conn, $sql)) {
    echo " record Delete successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);

}

}
 ?>
</table>

    </form>
    

</center>
 			</div>
 		<div id="footer" style="margin-top:10%; ">
 			<img src="footer.png" width="1200"  >
 		
 		</div>
 	</div>
 	<div id="right"></div>
 </div>

</body>
</html>