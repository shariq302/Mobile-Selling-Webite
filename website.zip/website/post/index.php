



<!DOCTYPE html>
<html>
<head>
	<title> Buy</title>

	<link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
 <div id="body" style="background-color: lightblue">
 	<div id="left"></div>
 	<div id="center">
 		<div id="head"></div>
 		<div id="subhead">
<input type="text" placeholder="Search" id="search" >
			
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/home%20page/' "><i class="fa fa-home" >Home</button>
<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/contact%20us%20page/' " >Contact Us</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/sign%20up/' ">Sign Up</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/login/' " >Login</button>
 		</div>
 		<div id="mid">

 		<div id="details">
 			<button style="margin-left: 94%; border-radius: 25%" onclick="window.location.href='http://localhost:2124/website/Buy/index0.php' ">X</button>

 			<div id="img"> 
            <img src="1.jpg" style="height: 380px;width: 230px"> 	
 			</div>
 			<div id="text">
 				<label>Title</label>
 				<input type="text" name="txttitle"><br>
 				<label>Description</label>
 				<input type="text" name="txtdescription"><br>
 				<label>Upload picture</label>
 				<input type="text" name="txtimage"><br>
 				<label>Name</label>
 				<input type="text" name="txtname"><br>
 				<label>COntact Number</label>
 				<input type="text" name="txtcontact"><br>

 				<button style="width: 200px;height: 40px; margin-left: 10%;border:5px solid black" onclick="window.location.href='http://localhost:2124/website/product/credit.php' ">Add Cart</button>
 			</div>
 		</div>
 		</div>
 		<div id="footer">
 		
 		</div>
 	</div>
 	<div id="right"></div>
 </div>

</body>
</html>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbimage";

// Create connection
$conn =  mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed ");
}

$Title=$_POST['txttitle'];
$Description=$_POST['txtdescription'];
$Image=$_POST['txtimage'];
$Name=$_POST['txtname'];
$contact=$_POST['txtcontact'];

$sql ="INSERT INTO image(Title,Description,Image,Name,Contact) VALUES('$Title','$Description','$Image','$Name','$Contact')";

if (!mysqli_query($conn, $sql)) {
    echo "not updated";
} 
mysqli_close($conn);

?>