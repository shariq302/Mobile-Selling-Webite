

<!DOCTYPE html>
<html>
<head>
	<title>signup</title>
<link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<?php
error_reporting(0);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "e-commerce";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$fname=$_POST['txtfname'];
$lname=$_POST['txtlname'];
$email=$_POST['txtemail'];
$password=$_POST['txtpassword'];
$cpassword=$_POST['txtcpassword'];
$date=$_POST['date'];
$month=$_POST['month'];
$year=$_POST['year'];


if (isset($_POST["signup"])) {
  
     // Your validation code.
     if (empty($password)) {

          
echo '<script language="javascript">';
echo 'alert("Password is required.")';
echo '</script>';
          
     } 
     else if ($password != $cpassword) {
         // error matching passwords


echo '<script language="javascript">';
echo 'alert("Your passwords do not match. Please type carefully.")';
echo '</script>';  

     }

     else if ($password == $cpassword) {
         // error matching passwords
         
         header( "Location: http://localhost:2124/website/Buy/index0.php" );}
     // passwords match

$sql = "INSERT INTO signup 
VALUES ('$fname', '$lname', '$email','$password','$date','$month','$year')";
if (mysqli_query($conn, $sql)) {
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);

}


}
?>

	
</head>
<body>
<div id="body" >
	<div id="left"></div>
	<div id="center">
		<div id="head"></div>
		<div id="subhead">
			<input type="text" placeholder="Search" id="search" >
			
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/home%20page/' "><i class="fa fa-home" >Home</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/Buy/index0.php' " >Buy</button>
        <button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/contact%20us%20page/' " >Contact Us</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/login/' " >Login</button>
		</div>
		<div id="content">
			<div id="mid" style="margin-left: 28%">
						<h1 style="color: white">Sign Up Here</h1>
					

			<form method="POST"  >
				<p>Firstname</p>
				<input type="name" name="txtfname" required="" placeholder="Enter Firstname" style="height: 40px; ">
				<p>Lastname</p>
				<input type="Lastname" name="txtlname" required="" placeholder="Enter Lastname" style="height: 40px">
				<p>Email</p>
				<input type="Email" name="txtemail" required="" placeholder="Enter Email" style="height: 40px">
				<p>Password</p>
				<input type="Password" name="txtpassword" required="" placeholder="********" style="height: 40px">
				
				<p>Password</p>
				<input type="Password" name="txtcpassword" required="" placeholder="********" style="height: 40px">
                <p>Enter Date Of Birth</p>
				<select required="" name="month">
                    <option value="Enter month" >Enter month</option>
                    <option value="Dec">Dec</option>
                    <option value="Jan">Jan</option>
					<option value="Feb">Feb</option>
					<option value="March">March</option>
					<option value="April">April</option>
                    <option value="May">May</option>
					<option value="June">June</option>
					<option value="July">July</option>
					<option value="Aug">Aug</option>
					<option value="Sep">Sep</option>
					<option value="Oct">Oct</option>
					<option value="Nov">Nov</option>              
                  </select>

                  <select required="" name="date">
                    <option value="Enter Date" >Enter Date</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
                    <option value="6">6</option>
					<option value="7">7</option>
					<option value="8">8</option>
					<option value="9">9</option>
					<option value="10">10</option>
					<option value="11">11</option>
					<option value="12">12</option>
					<option value="9">13</option>
					<option value="10">14</option>
					<option value="11">15</option>
					<option value="12">16</option>              
                  </select>

                  <select name="year" required="">
                    <option value="Enter year" >Enter year</option>
                    <option value="1999">1999</option>
                    <option value="2000">2000</option>
					<option value="2001">2001</option>
					<option value="2001">2002</option>
					<option value="2003">2003</option>
                    <option value="2004">2004</option>
					<option value="2005">2005</option>
					<option value="2006">2006</option>
					<option value="2007">2007</option>
					<option value="2008">2008</option>
					<option value="2009">2009</option>
					<option value="12">2010</option>
					<option value="9">2011</option>
					<option value="10">2012</option>
					<option value="11">2013</option>
					<option value="12">2014</option>              
                  </select>
                  <br>
                  <input type="submit" name="signup" value="Sign Up" onclick="return Validate()">
			</form>
                 </div>
		</div>
		</div>
		<div id="footer"></div>
	</div>
	<div id="right"></div>
</div>
</body>
</html>