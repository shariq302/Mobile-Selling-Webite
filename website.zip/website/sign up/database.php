<?php
$con=mysqli_connect("localhost","root","");
if (!$con) {
echo "not connected to server";
}
if (!mysqli_select_db($con,"signup")) {
	echo "not selected database";
}
$fname=$_POST["Firstname"];
$lname=$_POST["Lastname"];
$email=$_POST["Email"];
$password=$_POST["Pass"];
$confirm_password=$_POST["Cpass"];

 $sql="INSERT INTO data (Firstname,Lastname,Email,Password,ConfirmPassword) VALUES ('$fname','$lname','$email','$password','$confirm_password')";

 if (!mysqli_query($con,$sql)) {
echo "not inserted";
 }
 else {
echo "inserted";
 }
 header("refresh:10; url=index.php");
?>

 

