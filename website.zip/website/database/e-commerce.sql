-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 27, 2018 at 11:03 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e-commerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `addproduct`
--

CREATE TABLE `addproduct` (
  `image` varchar(1000) NOT NULL,
  `title` varchar(100) NOT NULL,
  `id` int(11) NOT NULL,
  `description` varchar(500) NOT NULL,
  `amount` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addproduct`
--

INSERT INTO `addproduct` (`image`, `title`, `id`, `description`, `amount`) VALUES
('img/2.jpg', 'HTC', 2, ' \r\nSamsung Galaxy J7 (2017) smartphone was launched in June 2017. The phone comes with a 5.50-inch touchscreen display with a resolution of 1080 pixels by 1920 pixels. The Samsung Galaxy J7 (2017) is ', '30,000'),
('img/3.jpg', 'QMOBILE', 3, ' \r\nSamsung Galaxy J7 (2017) smartphone was launched in June 2017. The phone comes with a 5.50-inch touchscreen display with a resolution of 1080 pixels by 1920 pixels. The Samsung Galaxy J7 (2017) is ', '16,000'),
('img/5.jpg', 'Samsung', 4, ' \r\nSamsung Galaxy J7 (2017) smartphone was launched in June 2017. The phone comes with a 5.50-inch touchscreen display with a resolution of 1080 pixels by 1920 pixels. The Samsung Galaxy J7 (2017) is ', '13,000'),
('img/6.jpg', 'QMOBILE', 5, ' \r\nSamsung Galaxy J7 (2017) smartphone was launched in June 2017. The phone comes with a 5.50-inch touchscreen display with a resolution of 1080 pixels by 1920 pixels. The Samsung Galaxy J7 (2017) is ', '3,000'),
('img/7.jpg', 'VIVO', 6, ' \r\nSamsung Galaxy J7 (2017) smartphone was launched in June 2017. The phone comes with a 5.50-inch touchscreen display with a resolution of 1080 pixels by 1920 pixels. The Samsung Galaxy J7 (2017) is ', '19,700'),
('img/9.png', 'Honours', 7, '2017) smartphone was launched in June 2017. The phone comes with a 5.50-inch touchscreen display with a resolution of 1080 pixels by 1920 pixels. The Samsung Galaxy J7 (2017) is p', '30,000'),
('img/8.jpg', 'QMOBILE', 8, '(2017) smartphone was launched in June 2017. The phone comes with a 5.50-inch touchscreen display with a resolution of 1080 pixels by 1920 pixels. The Samsung Galaxy J7 (2017) is p', '30,000'),
('img/10.jpg', 'HTC', 9, '(2017) smartphone was launched in June 2017. The phone comes with a 5.50-inch touchscreen display with a resolution of 1080 pixels by 1920 pixels. The Samsung Galaxy J7 (2017) is p', '80,000'),
('img/12.jpg', 'Samsung', 10, '(2017) smartphone was launched in June 2017. The phone comes with a 5.50-inch touchscreen display with a resolution of 1080 pixels by 1920 pixels. The Samsung Galaxy J7 (2017) is p', '45,000'),
('img/8.jpg', 'NOKIA', 11, '(2017) smartphone was launched in June 2017. The phone comes with a 5.50-inch touchscreen display with a resolution of 1080 pixels by 1920 pixels. The Samsung Galaxy J7 (2017) is p', '5,000'),
('img/9.jpg', 'Honours', 12, '(2017) smartphone was launched in June 2017. The phone comes with a 5.50-inch touchscreen display with a resolution of 1080 pixels by 1920 pixels. The Samsung Galaxy J7 (2017) is p', '50,000'),
('img/1.jpg', 'Samsung', 1, 'smartphone was launched in June 2017. The phone comes with a 5.50-inch touchscreen display with a resolution of 1080 pixels by 1920 pixels. 13-megapixel front shooter for selfies', '35000');

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `name` char(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `number` int(11) NOT NULL,
  `message` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`name`, `email`, `number`, `message`) VALUES
('samsung', 'shariq@gmail.com', 2147483647, 'DDDFDFDFDFDF');

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `name` char(25) NOT NULL,
  `number` int(20) NOT NULL,
  `address` varchar(35) NOT NULL,
  `city` varchar(20) NOT NULL,
  `payment` varchar(30) NOT NULL,
  `quantity` int(20) NOT NULL,
  `message` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`name`, `number`, `address`, `city`, `payment`, `quantity`, `message`) VALUES
('shariq', 2147483647, 'pakistan', 'karcahi', 'Cash On Delivery', 2, ',jjkljkgh'),
('bilal', 3, 'ka', 'pa', 'Credit Card', 3, 'kdyhuksgdysgy'),
('bilal', 3, 'ka', 'pa', 'Credit Card', 3, 'kdyhuksgdysgy'),
('bilal', 3, 'ka', 'pa', 'Credit Card', 3, 'kdyhuksgdysgy'),
('shariq', 2147483647, 'PA KARAVHG', 'BILAWAL', 'Cash On Delivery', 5, 'JALDE');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `firstname` char(39) NOT NULL,
  `lastname` char(39) NOT NULL,
  `email` varchar(40) NOT NULL,
  `Password` int(11) NOT NULL,
  `date` varchar(10) NOT NULL,
  `month` varchar(20) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`firstname`, `lastname`, `email`, `Password`, `date`, `month`, `year`) VALUES
('', 'ali', 'shariq@gmail.com', 1111111, '0000-00-00', '', 0),
('', 'ali', 'shariq@gmail.com', 1111111, '', '', 0),
('syed', 'shariq', 'syedshariq@gmail.ci', 123456, '9', 'Feb', 2001),
('syed', 'shariq', 'syedshariq@gmail.ci', 123456, '9', 'Feb', 2001),
('ssss', 'sss', 'shariq@gmail.com', 12345, '9', 'Aug', 2007),
('ssss', 'sss', 'shariq@gmail.com', 12345, '9', 'Aug', 2007),
('syed', 'ahmed', 'admin@gmail.com', 11111, 'Enter Date', 'Enter month', 0),
('shariq', 'shariq', 'shariq@gmail.com', 1111, 'Enter Date', 'Enter month', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
