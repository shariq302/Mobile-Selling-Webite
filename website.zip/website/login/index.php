

<?php
error_reporting(0);
if (isset($_POST['btnlogin'])) 
{
$a = $_POST['txtemail'];
$_SESSION['txtemail'] = $a;
$b = $_POST['txtpass'];
$_SESSION['txtpass'] = $a;

}


?>
		<?php 
if ($a=="admin@gmail.com" || $b=="1234") {
header('location: http://localhost:2124/website/Add%20Product/add.php');	
}
elseif($a=="" || $b==""){
	echo "enter email/password";
}
else{
	echo "wrong password";
}

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
	

</head>
<body>
<div id="body" >
	<div id="left"></div>
	<div id="center" >
		<div id="head"></div>
		<div id="subhead">
			<div id="subhead">
				
		

			<input type="text" placeholder="Search" id="search" >
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/home%20page/' "><i class="fa fa-home" >Home</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/Buy/index0.php' " >Buy</button>
			<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/contact%20us%20page/' " >Contact Us</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/sign%20up/' ">Sign Up</button>

	</div>
		</div>
		<div id="main">
			<div  id="loginBox">
		<h1 style="color: white;font-style: initial" >LOG IN </h1>
		<form name="input" method="POST" >
			<p style="font-style: initial">Email</p>
			<input  type="Email" name="txtemail" placeholder="Enter Email" required>
			<p style="font-style: initial">password</p>
			<input  type="password" name="txtpass" placeholder="******" required>
			<input type="submit" value="Login" name="btnlogin">
			<a  href="http://localhost:2124/website/sign%20up/"> Forgotten Account? &nbsp;Sign Up
				</a>		
		</form>
	

	</div>
		</div>
 
		<div id="footer"></div>
	<div id="footer"></div>


</div>
</body>

</html>