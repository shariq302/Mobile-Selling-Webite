


<!DOCTYPE html>
<html>
<head>
	<title>contact us</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
	<div id="body" >
		<?php
error_reporting(0);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "e-commerce";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$name=$_POST['txtname'];
$email=$_POST['txtemail'];
$number=$_POST['txtnumber'];
$message=$_POST['txtmessage'];

if (isset($_POST["contact"])) {

$sql = "INSERT INTO contactus 
VALUES ('$name', '$email','$number','$message')";
if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);

}


}
?>


		<div id="left"></div>

		<div id="center" >
		<div id="head"></div>
		<div id="subhead">
			<input type="text" placeholder="Search" id="search" >
			
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/home%20page/' "><i class="fa fa-home" >Home</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/Buy/index0.php' " >Buy</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/sign%20up/' ">Sign Up</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/login/' " >Login</button>
		
	</div>
		<div id="main">
			<h1 id="subheading"> Contact Us</h1>
		<div id="contant">
			<form method="POST">
      					<div class="col-md-4 form-line">
			  			<div class="form-group">
			  				<label >Your name</label>
					    	<input type="text" class="form-control" placeholder=" Enter Name" name="txtname">
				  		</div>
				  		<div class="form-group">
					    	<label >Email Address</label>
					    	<input type="email" class="form-control" placeholder=" Enter Email id" name="txtemail">
					  	</div>	
					  	<div class="form-group">
					    	<label for="telephone">Mobile No.</label>
					    	<input type="no" class="form-control" name="txtnumber" placeholder=" Enter 10-digit mobile no.">
			  			</div>
			  			<div class="form-group">
                            <label > Message</label>
			  			 	<textarea  class="form-control" name="txtmessage" placeholder="Enter Your Message"></textarea>
			  				
			  				<input value="Send Message" type="submit" name="contact" class="btn btn-primary">
                             
                             </input>
			  			</div>
</form>
			  		</div>
			  		<div class="col-md-6">
			  			<div class="form-group">
			  				
			  			 	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d226.13031260794335!2d67.09729147537898!3d24.929174051509637!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb338b5a06649fb%3A0x3c125a543a0822f3!2sRehman+Cigarette+Shop!5e0!3m2!1sen!2s!4v1520227731641" width="400"; height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
			  			</div>
			  		</div>
			  	</div>
			  </div>
		<div id="footer"></div>		
		</div>
		<div id="right"></div>
		</div>

</body>
</html>