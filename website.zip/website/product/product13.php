<!DOCTYPE html>
<html>
<head>
	<title> Buy</title>
	<link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
 <div id="body" >
 	<div id="left"></div>
 	<div id="center">
 		<div id="head"></div>
 		<div id="subhead">
<input type="text" placeholder="Search" id="search" >
			
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/home%20page/' "><i class="fa fa-home" >Home</button>
<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/contact%20us%20page/' " >Contact Us</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/sign%20up/' ">Sign Up</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/login/' " >Login</button>
 		</div>
 		<div id="mid">
 		<div id="details">
 			<button style="margin-left: 94%; border-radius: 25%" onclick="window.location.href='http://localhost:2124/website/Buy/index0.php' ">X</button>

 			<div id="img"> 
            <img src="13.jpg" style="height: 380px;width: 230px"> 	
 			</div>
 			<div id="text">
 				<p style="color:white;font-size:15px;font-style: italic;  ">

 					<strong>Samsung Galaxy J7 (2017)</strong> smartphone was launched in June 2017. The phone comes with a 5.50-inch touchscreen display with a resolution of 1080 pixels by 1920 pixels.

The Samsung Galaxy J7 (2017) is powered by 1.6GHz octa-core Exynos 7870 processor and it comes with 3GB of RAM. The phone packs 16GB of internal storage that can be expanded up to 256GB via a microSD card. As far as the cameras are concerned, the Samsung Galaxy J7 (2017) packs a 13-megapixel primary camera on the rear and a 13-megapixel front shooter for selfies.
</p>
 				<button style="width: 200px;height: 40px; margin-left: 10%;border:5px solid black "onclick="window.location.href='http://localhost:2124/website/product/credit.php' ">Add Cart</button>
 			</div>
 		</div>
 		</div>
 		<div id="footer">
 		<img src="footer.png" style="width: 1200px;height: 250px;">
 		
 		</div>
 	</div>
 	<div id="right"></div>
 </div>

</body>
</html>