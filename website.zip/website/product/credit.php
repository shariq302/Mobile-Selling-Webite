<!DOCTYPE html>
<html>
<head>
	<title> Buy</title>

 <?php
error_reporting(0);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "e-commerce";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$NAME=$_POST['txtname'];
$NUMBER=$_POST['txtnumber'];
$ADDRESS=$_POST['txtaddress'];
$CITY=$_POST['txtcity'];
$PAYMENT=$_POST['txtpayment'];
$QUANTITY=$_POST['txtquantity'];
$MESSAGE=$_POST['txtmessage'];

if (isset($_POST["Purchased"])) {
  

$sql = "INSERT INTO purchase 
VALUES ('$NAME', '$NUMBER', '$ADDRESS','$CITY','$PAYMENT', '$QUANTITY','$MESSAGE')";
if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);

}
}

if (isset($_POST["Update"])) {

$sql = "UPDATE  purchase 
SET name='$NAME',number='$NUMBER',address='$ADDRESS',city='$CITY',payment='$PAYMENT',quantity='$QUANTITY',message='$MESSAGE'
WHERE name='$NAME'";

if (mysqli_query($conn, $sql)) {
    echo " record updated successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);

}

}
if (isset($_POST["Delete"])) {

$sql = "DELETE FROM purchase 

WHERE name='$NAME'";

if (mysqli_query($conn, $sql)) {
    echo " record Delete successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);

}

}


mysqli_close($conn);


?>


	<link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
 <div id="body" >
 	<div id="left"></div>
 	<div id="center">
 		<div id="head"></div>
 		<div id="subhead">
<input type="text" placeholder="Search" id="search" >
			
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/home%20page/' "><i class="fa fa-home" >Home</button>
<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/contact%20us%20page/' " >Contact Us</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/sign%20up/' ">Sign Up</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/login/' " >Login</button>
 		</div>
 		<div id="mid">
 			<div id="details" style="width: 400px;height: 650px;margin-left: 33% ">
      <button style="margin-left: 94%; border-radius: 25%" onclick="window.location.href='http://localhost:2124/website/Buy/index0.php' ">X</button>
      <form method="POST">
        <label style="color: white;font-size:20px " >Full Name</label><br>
        <input style="float: right;width: 390px;height: 30px " type="text" name="txtname" ><br>
        <label style="color: white;font-size:20px ">Contact Number</label><br>
        <input style="float: right;width: 390px;height: 30px " type="text" name="txtnumber" required><br>
        <label style="color: white;font-size:20px ">Delivery Address</label><br>
        <input style="float: right;width: 390px;height: 30px " type="text" name="txtaddress" ><br>
        <label style="color: white;font-size:20px ">City</label><br>
        <input style="float: right;width: 390px;height: 30px " " type="text" name="txtcity" ><br>
        <label style="color: white;font-size:20px ">Payment Option</label><br>
            <input type="radio" name="txtpayment"  value="Cash On Delivery"><label style="color: white"> Cash On Delivery</label><br>
            <input type="radio" name="txtpayment"  value="Credit Card"><label style="color: white"> Credit Card </label><br>
            <input type="radio" name="txtpayment"  value="Online Bank Deposit"><label style="color: white"> Online Bank Deposit</label><br>
       <label style="color: white;font-size:20px ">Quantity</label><br>
       <select  name="txtquantity">
         <option value="1">1</option>
         <option value="2">2</option>
         <option value="3">3</option>
         <option value="4">4</option>
         <option value="5">5</option>
       </select> <br>
       <label style="color: white;font-size:20px ">Any Message</label><br>
       <input style="float: right;width: 390px;height: 30px;height: 70px ;border:5px;border-radius: 20px" type="text" name="txtmessage">
       <input type="submit" value="Purchased" name="Purchased" style="width: 100px;height: 40px;border:5px solid black;margin-left:5%;margin-top: 5%; ">
       <input type="submit" value="Update" name="Update"  style="width: 100px;height: 40px;border:5px solid black; margin-left: 4%;margin-top: 5%; ">
 

    
              <input type="submit" value="Delete" name="Delete" style="width: 100px;height: 40px;border:5px solid black; margin-left: 5%; margin-top: 5%; ">
       
               
      </form>
    </div>
    <div id="footer">
    <img src="footer.png" style="width: 1200px;height: 200px;margin-top: 7.5%">
      
    </div>
  </div>
  <div id="right"></div>
 </div>

</body>

</html>