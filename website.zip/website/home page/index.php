<!DOCTYPE html>
<html>
<head>
	<title>home page</title>
	<link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
	<div id="body"  >
<div class="five columns">
	<div id="left">
	</div>
		</div>
	<div id="center">
		<div class="twelve columns">
		<div id="head" >
		
		</div>
		<div id="subhead">
<input type="text" placeholder="Search" id="search" style="height: 60px; text-align: center;" >
			
			
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/Buy/index0.php' " >Buy</button>
			<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/contact%20us%20page/' " >Contact Us</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/signup/' " >signup</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/login/' " >Login</button>      
		</div>   
	</div>
	<div class="seven columns">
		<div id="main">
			<div id="slider" style="max-width:100%">
  <img class ="mySlides" src="pic0.png" style="width:100%">
  <img class="mySlides" src="pic1.jpg" style="width:100%">
  <img class="mySlides" src="pic2.jpg" style="width:100%">
  <img class ="mySlides" src="pic3.jpg" style="width:100%">
  <img class="mySlides" src="pic4.jpg" style="width:100%;height: 680px">
</div>

<script>
var myIndex = 0;
Auto();

function Auto() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(Auto, 3000); // Change image every 2 seconds
}
</script>
			</div>
	</div>
	<div class="twelve columns"></div>

		<div id="footer">
			<img src="footer.png" style="width: 1200px">
		</div>
	</div>
	</div>
	<div class="five columns">
	<div id="right">
	</div>
	</div>
   </div>
</div>

</body>
</html>