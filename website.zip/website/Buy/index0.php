<!DOCTYPE html>
<html>
<head>
	<title> Buy</title>
	<link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
 <div id="body" >
 	<div id="left"></div>
 	<div id="center">
 		<div id="head"></div>
 		<div id="subhead">
<input type="text" placeholder="Search" id="search" >
			
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/home%20page/' "><i class="fa fa-home" >Home</button>
<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/contact%20us%20page/' " >Contact Us</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/sign%20up/' ">Sign Up</button>
		<button id="btn" type="button" class=" btn-primary" onclick="window.location.href='http://localhost:2124/website/login/' " >Login</button>
 		</div>
 		<div id="mid">
 			<div id="firstrow">
 				<button id="first" onclick="window.location.href='http://localhost:2124/website/product/product1.php' ">
 					<img  src="1.jpg" width="215" height="220" style="border-radius: 10%; border-bottom: 5px solid black">
 					<p style="color: black "> <strong>Samsung Galaxy On5 (2016)
                     Rs18,000 Off 6%Rs16,999</p></strong>
 				
        </button>
 				<button id="second" onclick="window.location.href='http://localhost:2124/website/product/product2.php' ">
 					<img src="2.jpg" width="215" height="220" style="border-radius: 10%;border-bottom: 5px solid black">
 					<p style="color: black"> <strong>Oale X1 Dual Sim Fingerprint Sensor
                     Rs15,000 Off 35%Rs9,699</p></strong>
 					
 				</button>
 				<button id="third" onclick="window.location.href='http://localhost:2124/website/product/product3.php' ">
 					<img src="3.jpg" width="215" height="220" style="border-radius: 10%;border-bottom: 5px solid black">
                    <p style="color: black"> <strong>Samsung Galaxy J3 Pro 2017 (4G, 32GB, Black)
                     Rs21,000 Off 9%Rs19,199</p></strong>
 					
 				</button>
 				<button id="forth" onclick="window.location.href='http://localhost:2124/website/product/product5.php' ">
 					<img src="5.jpg" width="215" height="220" style="border-radius: 10%;border-bottom: 5px solid black">
                    <p style="color: black"> <strong>Oale X2 Dual Sim (Gold With Fingerprint Sensor)
                    Rs15,000 Off 40%Rs8,999</p></strong>
 				</button>
 					
 			</div>
 			<div id="secondrow">
 				<button id="first" onclick="window.location.href='http://localhost:2124/website/product/product6.php' ">

 					<img src="6.jpg" width="215" height="220" style="border-radius: 10%;border-bottom: 5px solid black">
                    <p style="color: black"> <strong>Oale X2 Dual Sim (Gold With Fingerprint Sensor)
                    Rs15,000 Off 40%Rs8,999</p></strong>
 				</button>
 				<button id="second" onclick="window.location.href='http://localhost:2124/website/product/product7.php' ">
 					<img src="7.jpg" width="215" height="220" style="border-radius: 10%;border-bottom: 5px solid black">
                    <p style="color:black"> <strong>Oale X2 Dual Sim (Gold With Fingerprint Sensor)
                    Rs15,000 Off 40%Rs8,999</p></strong>
 				</button>
 				<button id="third" onclick="window.location.href='http://localhost:2124/website/product/product8.php' ">
 					<img src="8.jpg" width="215" height="220" style="border-radius: 10%;border-bottom: 5px solid black">
                    <p style="color:black"> <strong>Oale X2 Dual Sim (Gold With Fingerprint Sensor)
                    Rs15,000 Off 40%Rs8,999</p></strong>
 				</button>
 				<button id="forth" onclick="window.location.href='http://localhost:2124/website/product/product9.php' ">
 					<img src="9.jpg" width="215" height="220" style="border-radius: 10%;border-bottom: 5px solid black">
                    <p style="color: black"> <strong>Oale X2 Dual Sim (Gold With Fingerprint Sensor)
                    Rs15,000 Off 40%Rs8,999</p></strong>
 				</button>
 			</div>
 			<div id="thirdrow">
 				<button id="first" onclick="window.location.href='http://localhost:2124/website/product/product10.php' ">
 					<img src="10.jpg" width="215" height="220" style="border-radius: 10%;border-bottom: 5px solid black">
                    <p style="color: black"> <strong>Oale X2 Dual Sim (Gold With Fingerprint Sensor)
                    Rs15,000 Off 40%Rs8,999</p></strong>
 				</button>
 				<button id="second" onclick="window.location.href='http://localhost:2124/website/product/product11.php' ">
 					<img src="11.jpg" width="215" height="220" style="border-radius: 10%;border-bottom: 5px solid black">
                    <p style="color:black"> <strong>Oale X2 Dual Sim (Gold With Fingerprint Sensor)
                    Rs15,000 Off 40%Rs8,999</p></strong>
 				</button>
 				<button id="third" onclick="window.location.href='http://localhost:2124/website/product/product12.php' ">
 					<img src="12.jpg" width="215" height="220" style="border-radius: 10%;border-bottom: 5px solid black">
                    <p style="color:black"> <strong>Oale X2 Dual Sim (Gold With Fingerprint Sensor)
                    Rs15,000 Off 40%Rs8,999</p></strong>
 				</button>
 				<button id="forth" onclick="window.location.href='http://localhost:2124/website/product/product13.php' ">
 					<img src="13.jpg" width="215" height="220" style="border-radius: 10%;border-bottom: 5px solid black">
                    <p style="color:black"> <strong>Oale X2 Dual Sim (Gold With Fingerprint Sensor)
                    Rs15,000 Off 40%Rs8,999</p></strong>
 				</button>
 			</div>
 		</div>
 		<div id="footer">
 			<button style="margin-left: 40%; margin-top: 3%">
 			<a href="http://localhost:2124/website/Add%20Product/fetch.php">Page 0</a>
 		</button>
    <button style="">
      <a href="http://localhost:2124/website/Buy/index0.php">Page 1</a>
    </button>
 		<button >
 			<a href="http://localhost:2124/website/Buy/index1.php">Page 2</a>
 		</button>
 		<button >
 			<a href="http://localhost:2124/website/Buy/index2.php">Page 3</a>
 		</button>
 		</div>
 	</div>
 	<div id="right"></div>
 </div>

</body>
</html>